## opencore macOS 10.15.4
1. opencore 0.5.8
2. gigabyte H310M A 2.0(rev 1.0)
3. i5-9400
